# Commands Header
- all headers for commands, linke `pkexec` or `adb`/`fastboot`
