# Main Parts
- all main parts of the main UI from the fastboot-assistant
