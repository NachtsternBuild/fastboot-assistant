# Part of the application
- Here you will find all files customized for Windows via WSL from the *preflash* folder
