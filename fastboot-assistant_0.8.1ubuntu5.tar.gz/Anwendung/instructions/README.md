# Part of the application
## Tasks
- Instructions on how to use the application
  - flashing files
  - other work with Fastboot
  - etc.
- Instructions for working with Fastboot/ADB
- Information about Fastboot/ADB, Android devices and partitions 
