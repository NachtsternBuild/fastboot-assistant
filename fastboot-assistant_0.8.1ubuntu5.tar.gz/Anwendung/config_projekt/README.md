# Part of the application
## Tasks
- Create the necessary directories
- delete old files of the fastboot-assistant
- Change language
- Switch between dark and light design
