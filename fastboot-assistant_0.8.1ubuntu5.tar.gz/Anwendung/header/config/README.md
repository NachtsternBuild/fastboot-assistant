# Config Headers
- all config headers for the fastboot-assistant
