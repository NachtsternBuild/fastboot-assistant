# Part of the application
## Tasks
- Flashing images
  - boot.img
  - init_boot.img
  - vendor_boot.img
  - recovery.img
  - vendor.img
  - system.img
  - vbmeta.img
  - dtbo.img
  - userdata.img/data.img
  - u.a.
- flashing the preloader
- flashing the Payload.zip
