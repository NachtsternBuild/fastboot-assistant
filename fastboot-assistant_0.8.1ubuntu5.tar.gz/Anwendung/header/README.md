# Part of the application
- All program parts that are used repeatedly by several functions are located here.
