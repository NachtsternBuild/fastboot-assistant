# Part of the application
## Tasks
- Backup → root or without root (thanks to @mrrfv for Open Android Backup)
- Delete user data
- Open/close bootloader
- Prepare files for flash
- set active slot
- rework partitions
