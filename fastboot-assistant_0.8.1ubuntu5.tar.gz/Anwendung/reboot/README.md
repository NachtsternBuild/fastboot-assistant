# Part of the application
## Tasks
- Reboot in Fastboot
- Reboot in Recovery
- Reboot with heimdall
- Reboot
