# Header Partitions
- all headers for the work with partitions
